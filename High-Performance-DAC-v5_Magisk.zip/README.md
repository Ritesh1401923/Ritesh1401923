# Project Dead

##### High Performance DAC | Magisk Module

##### Contact: https://t.me/AkiraSuper

##### - This Magisk module enables the "High Performance DAC" mode of Qualcomm's WCD9xx DAC to maximize it's power and get the best audio quality possible.

##### ✓ INSTALLATION: Just flash via Magisk and reboot.

##### Disclaimer: Naturally, you take all the responsibility for what happens to your device when you start messing around with things. I (Akira) will not be responsible for ANY damage caused to anyone's devices due to the use of this module.
